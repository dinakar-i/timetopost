import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule } from '@angular/forms';
import { JobComponent } from './job/job.component';
import { PhonePreviewComponent } from '../Shared/phone-preview/phone-preview.component';
@Component({
  selector: 'app-scheduled-jobs',
  standalone: true,
  imports: [CommonModule, JobComponent, MatSelectModule, FormsModule, PhonePreviewComponent],
  templateUrl: './scheduledjobs.component.html',
  styleUrls: ['./scheduledjobs.component.scss'],
})
export class ScheduledjobsComponent {
  jobs = [
    {
      id: 'J-101',
      title: 'Ocean Teaser Campaign',
      platform: 'Reel',
      creator: 'Dinakar M.',
      time: '2025-08-22 10:00 AM',
      status: 'Scheduled',
      image: 'assets/images/ocean-teaser.jpg',
    },
    {
      id: 'J-102',
      title: 'Feature Highlight',
      platform: 'Video',
      creator: 'Riya P.',
      time: '2025-08-18 09:00 AM',
      status: 'Published',
      image: 'assets/images/ocean-teaser.jpg',
    },
    {
      id: 'J-103',
      title: 'Behind the Scenes',
      platform: 'Post',
      creator: 'Sam K.',
      time: '2025-08-19 05:00 PM',
      status: 'Published',
      image: 'assets/images/ocean-teaser.jpg',
    },
    {
      id: 'J-104',
      title: 'New Trailer Release',
      platform: 'Carousel',
      creator: 'Dinakar M.',
      time: '2025-08-25 07:30 PM',
      status: 'Scheduled',
      image: 'assets/images/ocean-teaser.jpg',
    },
    {
      id: 'J-105',
      title: 'Draft Post Example',
      platform: 'Story',
      creator: 'Riya P.',
      time: '2025-08-26 02:00 PM',
      status: 'Draft',
      image: 'assets/images/ocean-teaser.jpg',
    },
  ];
  selectedPlatform = 'All';
  selectedStatus = 'All';
  selectedJob: any = null;
  platforms = ['All', 'Reel', 'Video', 'Post', 'Carousel', 'Story'];
  statuses = ['All', 'Scheduled', 'Published', 'Draft'];

  get filteredJobs() {
    return this.jobs.filter(
      (job) =>
        (this.selectedPlatform === 'All' || job.platform === this.selectedPlatform) &&
        (this.selectedStatus === 'All' || job.status === this.selectedStatus)
    );
  }

  selectJob(job: any) {
    this.selectedJob = job;
  }
}
