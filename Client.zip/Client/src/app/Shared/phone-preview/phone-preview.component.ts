import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-phone-preview',
  standalone: true,
  templateUrl: './phone-preview.component.html',
  styleUrls: ['./phone-preview.component.scss'],
  imports: [CommonModule],
})
export class PhonePreviewComponent {
  @Input() job: any = null;
}
